﻿using DeltaEngine.Commands;
using DeltaEngine.Content;
using DeltaEngine.Core;
using DeltaEngine.Datatypes;
using DeltaEngine.Rendering3D;
using DeltaEngine.Rendering3D.Cameras;
using DeltaEngine.Rendering3D.Shapes;

namespace Labyrinth
{
	/// <summary>
	/// 3D example game written for the Chapter 3 of the Game Tools Gems book by Benjamin Nitschke.
	/// </summary>
	class Game
	{
		public Game(Window window)
		{
			LoadModelData();
			CreateGroundPlane();
			CreateLevel();
			SetupCamera();
			SetupInputCommands(window);
		}

		private void LoadModelData()
		{
			wall = ContentLoader.Load<ModelData>("Wall");
			box = ContentLoader.Load<ModelData>("Box");
			spikeball = ContentLoader.Load<ModelData>("Spikeball");
			dragon = ContentLoader.Load<ModelData>("Dragon");
		}

		private ModelData wall;
		private ModelData box;
		private ModelData spikeball;
		private ModelData dragon;

		private static void CreateGroundPlane()
		{
			new Model(new ModelData(new BoxMesh(new Vector3D(9, 9, 0.1f),
				new Material(ShaderFlags.LitTextured, "GroundDiffuse"))), new Vector3D(4, 4, 0));
		}

		private void CreateLevel()
		{
			for (int x = 0; x <= level.GetUpperBound(0); x++)
				for (int y = 0; y <= level.GetUpperBound(1); y++)
					CreateModel(x, y);
		}

		private Model CreateModel(int x, int y)
		{
			switch (level[y, x])
			{
			case 'W':
			case 'X':
				return new Model(wall, new Vector3D(x, y, 0));
			case 'B':
				return new Model(box, new Vector3D(x, y, 0))
				{
					Orientation = Quaternion.FromAxisAngle(Vector3D.UnitZ, 180)
				};
			case 'D':
				return new Model(dragon, new Vector3D(x, y, 0)) { Scale = Vector3D.One * 7 };
			case 'S':
				return new Model(spikeball, new Vector3D(x, y, 0.5f));
			}
			return null;
		}

		/// <summary>
		/// Level, currently 9x9. W=Wall, B=Box, X=Box+Wall, D=Dragon, S=Spikeball, G=Goal
		/// </summary>
		private readonly char[,] level =
		{
			{ 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', },
			{ 'W', 'D', 'W', 'X', 'W', ' ', 'W', 'X', 'W', },
			{ 'W', ' ', 'W', ' ', 'B', 'B', 'W', ' ', 'W', },
			{ 'W', 'B', 'W', 'B', 'W', ' ', 'W', 'B', 'W', },
			{ 'W', ' ', 'W', ' ', 'W', 'B', 'W', ' ', 'W', },
			{ 'W', 'B', 'B', 'B', 'B', ' ', 'B', ' ', 'W', },
			{ 'W', 'X', 'W', 'X', 'W', 'X', 'W', 'B', 'W', },
			{ 'W', 'S', 'B', ' ', 'B', ' ', 'B', 'G', 'W', },
			{ 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', },
		};

		private static void SetupCamera()
		{
			var camera = Camera.Use<LookAtCamera>();
			camera.Position = new Vector3D(2, 0, 3);
			camera.Target = new Vector3D(2, 1, 0.2f);
		}

		private static void SetupInputCommands(Window window)
		{
			new Command(Command.Exit, window.CloseAfterFrame);
		}
	}
}
