using DeltaEngine.Core;
using DeltaEngine.Platforms;
using DeltaEngine.Rendering2D.Fonts;

namespace Labyrinth
{
	public class Program : App
	{
		public Program()
		{
			new FpsDisplay();
			new Game(Resolve<Window>());
		}

		public static void Main()
		{
			new Program().Run();
		}
	}
}