﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: CLSCompliant(true)]
[assembly: AssemblyTitle("Labyrinth")]
[assembly: AssemblyDescription("Labyrinth 3D example game for the Game Tools Gems book chapter")]
[assembly: AssemblyCompany("Delta Engine")]
[assembly: AssemblyCopyright("Copyright Â© Delta Engine 2014")]
[assembly: ComVisible(false)]
[assembly: Guid("53b3ef11-7cd2-4cf6-a5bc-401e665be286")]
[assembly: AssemblyVersion("1.0.19")]
[assembly: AssemblyFileVersion("1.0.19")]